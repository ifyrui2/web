/* Product page enhancements (Nexys/Hyper style) */
(function () {
  function initGallery(root) {
    if (!root) return;

    // Reveal on scroll
    var rev = root.querySelectorAll('.reveal');
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (x) {
          if (x.isIntersecting) { x.target.classList.add('in'); io.unobserve(x.target); }
        });
      }, { threshold: 0.15, rootMargin: '-10px 0px -10px 0px' });
      rev.forEach(function (x) { io.observe(x); });
    } else {
      rev.forEach(function (x) { x.classList.add('in'); });
    }

    // Thumbnails active state
    root.querySelectorAll('.thumbnails button').forEach(function (b) {
      b.addEventListener('click', function () {
        b.parentNode.querySelectorAll('button').forEach(function (x) { x.classList.remove('active'); });
        b.classList.add('active');
      });
    });

    // Gentle parallax on hover
    var frame = root.querySelector('.prod-gallery .frame');
    if (frame) {
      var img = frame.querySelector('img');
      if (img) {
        frame.addEventListener('mousemove', function (ev) {
          var r = frame.getBoundingClientRect();
          var x = (ev.clientX - r.left) / r.width - 0.5;
          var y = (ev.clientY - r.top) / r.height - 0.5;
          img.style.transform = 'scale(1.07) translate(' + (x * 8) + 'px,' + (y * 8) + 'px)';
        }, { passive: true });
        frame.addEventListener('mouseleave', function () { img.style.transform = 'scale(1.02)'; }, { passive: true });
      }
    }
  }

  function boot() {
    document.querySelectorAll('.hyper-product').forEach(initGallery);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  // Alpine data: sales notifications (data comes from #hp-orders data attribute)
  document.addEventListener('alpine:init', function () {
    if (!window.Alpine) return;
    window.Alpine.data('salesNotifications', function () {
      var el = document.getElementById('hp-orders');
      var orders = [];
      try { orders = el ? JSON.parse(el.getAttribute('data-orders') || '[]') : []; } catch (e) { orders = []; }
      return {
        displayTime: 8000, initTimeMin: 2000, initTimeMax: 4000, nextTimeMin: 8000, nextTimeMax: 12000,
        latestOrders: orders, show: false,
        get order() { return this.latestOrders.length > 0 ? this.latestOrders[0] : null; },
        getRandomInterval: function (min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; },
        getTimeAgo: function (input) {
          var date = (input instanceof Date) ? input : new Date(input);
          var f = new Intl.RelativeTimeFormat('en');
          var ranges = { years: 31536000, weeks: 604800, days: 86400, hours: 3600, minutes: 60, seconds: 1 };
          var sec = (date.getTime() - Date.now()) / 1000;
          for (var k in ranges) if (ranges[k] < Math.abs(sec)) return f.format(Math.round(sec / ranges[k]), k);
          return 'just now';
        },
        showNotification: function () {
          var self = this;
          if (!this.latestOrders.length) return;
          this.show = true;
          setTimeout(function () {
            self.show = false;
            setTimeout(function () {
              self.latestOrders.shift();
              if (self.latestOrders.length) {
                setTimeout(function () { self.showNotification(); }, self.getRandomInterval(self.nextTimeMin, self.nextTimeMax));
              }
            }, 500);
          }, this.displayTime);
        },
        init: function () {
          var self = this;
          setTimeout(function () { self.showNotification(); }, this.getRandomInterval(this.initTimeMin, this.initTimeMax));
        }
      };
    });
  });
})();
